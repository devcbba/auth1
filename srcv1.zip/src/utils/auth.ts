export function isAuthenticated(): boolean {

  return localStorage.getItem("auth") === "true";
}

export function logout(): void {

  localStorage.removeItem("auth");
  localStorage.removeItem("user");
}

export function getUser() {

  const user = localStorage.getItem("user");

  return user ? JSON.parse(user) : null;
}