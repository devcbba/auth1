import axios from "axios";

import type {
  LoginResponse
} from "../types/auth";

const API_URL = "http://localhost/api";

export async function login(
  usuario: string,
  password: string
): Promise<LoginResponse> {

  try {

    const response = await axios.post<LoginResponse>(
      `${API_URL}/login.php`,
      {
        usuario,
        password,
      },
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );

    return response.data;

  } catch (error) {

    return {
      success: false,
      message: "Error de conexión"
    };
  }
}