export default function Home() {

  return (
    <div>

      <h1>
        Página Pública
      </h1>

      <p>
        Todos pueden entrar aquí
      </p>

    </div>
  );
}