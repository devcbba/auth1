export default function Dashboard() {

  return (
    <div>

      <h1>
        Dashboard Privado
      </h1>

      <p>
        Solo usuarios autenticados
      </p>

    </div>
  );
}