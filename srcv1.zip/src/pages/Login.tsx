import { useState } from "react";

import {
  useNavigate
} from "react-router-dom";

import {
  login
} from "../services/authService";

export default function Login() {

  const navigate = useNavigate();

  const [usuario, setUsuario] = useState("");
  const [password, setPassword] = useState("");

  const [error, setError] = useState("");

  const handleLogin = async (
    e: React.FormEvent
  ) => {

    e.preventDefault();

    setError("");

    const response = await login(
      usuario,
      password
    );

    if (
      response.success &&
      response.user
    ) {

      localStorage.setItem(
        "auth",
        "true"
      );

      localStorage.setItem(
        "user",
        JSON.stringify(response.user)
      );

      navigate("/dashboard");

    } else {

      setError(response.message);
    }
  };

  return (
    <div>

      <h1>Login</h1>

      <form onSubmit={handleLogin}>

        <input
          type="text"
          placeholder="Usuario"
          value={usuario}
          onChange={(e) =>
            setUsuario(e.target.value)
          }
        />

        <br /><br />

        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) =>
            setPassword(e.target.value)
          }
        />

        <br /><br />

        <button type="submit">
          Ingresar
        </button>

      </form>

      <br />

      {
        error && (
          <p>{error}</p>
        )
      }

    </div>
  );
}