import {
  Link,
  useNavigate
} from "react-router-dom";

import {
  getUser,
  logout
} from "../utils/auth";

export default function Navbar() {

  const navigate = useNavigate();

  const user = getUser();

  const handleLogout = () => {

    logout();

    navigate("/login");
  };

  return (
    <nav>

      <Link to="/">
        Home
      </Link>

      {" | "}

      <Link to="/dashboard">
        Dashboard
      </Link>

      {" | "}

      <Link to="/about">
        About
      </Link>

      {" | "}

      <button onClick={handleLogout}>
        Logout
      </button>

      <hr />

      <p>
        Usuario:
        {" "}
        {user?.usuario}
      </p>

      <p>
        Rol:
        {" "}
        {user?.rol}
      </p>

      <hr />

    </nav>
  );
}