export interface User {
  id: number;
  usuario: string;
  rol: string;
}

export interface LoginResponse {
  success: boolean;
  message: string;
  user?: User;
}